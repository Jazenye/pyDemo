from distutils.core import setup

setup(name="jazen", version="1.0", description="jazen's module", author="xingwenpeng", py_modules=['pack.a', 'pack.b'])